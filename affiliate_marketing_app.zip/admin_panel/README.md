
# Admin Panel

## Purpose
This React app serves as the admin panel, allowing model selection and real-time log viewing.

## Core Requirements
- Display real-time logs for backend and AI worker services.
- Implement "Choose Your AI" dropdown for selecting models.
