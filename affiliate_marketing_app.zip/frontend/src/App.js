
// App.js - Main entry point for the React frontend
// - Renders the Home, Trends, and Admin pages
// - Sets up routing and handles global states
// - Uses "Choose Your AI" dropdown to control AI model selection
